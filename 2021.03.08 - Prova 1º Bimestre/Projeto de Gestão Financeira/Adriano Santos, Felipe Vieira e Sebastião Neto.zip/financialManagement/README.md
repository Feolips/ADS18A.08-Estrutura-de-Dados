# financialManagement
Aplicação 'Financial Management' para gestão de finanças pessoais.

1ª Avaliação de Estrutura de Dados - 2020.

Grupo: Adriano Silva Santos, Felipe Souza Vieira e Sebastião Bispo dos Santos Neto.
