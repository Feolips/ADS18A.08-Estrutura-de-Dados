## This Application do emission of tickets, and stored in queue.

### It do the emission of tickets and stored in queue, which after is calling  according with prioritiy.
### Tickets for emission:

* P = Preferred (Priority 5)
* N = Normal Service (Priority 4)
* MD = Material Delivery (Priority 3)
* R = Results (Priority 2)
* G = Get Material (Priority 1)

*Artur-Cavalcante*
