# Add to path the folder of methods
import sys 
sys.path.append('/home/artur/github/ticket/src/methods')

from methods_ticket import request_choice_ticket, request_choice_menu
from methods_app import start_app, emission_ticket
from clear_screen import clear_screen