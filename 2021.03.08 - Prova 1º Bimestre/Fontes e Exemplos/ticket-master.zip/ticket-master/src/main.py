from methods.methods_app import start_app

start_app()