# Declaração da Classe
class retangulo:
 # lado1 = 1.0 // Optou-se por passar diretamente ao Construtor:
 # lado2 = 1.0

    # A função a seguir chama-se Construtor:

    def __init__(self, lado1 = 0.0, lado2 = 0.0):
        # self.lado1 = lado1
        # self.lado2 = lado2
        self.setlado1(lado1)
        self.setlado2(lado2)

    # Aqui o método 'set' indica o valor a ser calculado:

    def setlado1(self, lado1):
        self.lado1 = self.validamedidalado(lado1)
        return

    # Aqui o método 'get' indica qual valor a ser retornado:

    def getlado1(self):
        return self.lado1

    # Aqui os 'set' e 'get' para a segunda variável:

    def setlado2(self, lado2):
        self.lado2 = self.validamedidalado(lado2)
        return

    def getlado2(self):
        return self.lado2

    # Aqui, finalmente, o método utilizado para validar valores:

    def validamedidalado(self, medida):
        if isinstance(medida, float) and medida > 0:
            return medida
        else:
            return 0

    # Métodos para cálculos de área e perímetro:

    def perimetro(self):
        return (self.getlado1() * 2) + (self.getlado2() * 2)

    def area(self):
        return (self.getlado1() * self.getlado2())


    # Método de retorno de dados ao usuário:
    def saida(self):
        print('Dimensões do retângulo: {:.2f}cm por {:.2f}cm.'.format(self.getlado1(), self.getlado2()))
        print('Área: {:.2f}cm².'.format(self.area()))
        print('Perímetro: {:.2f}cm.'.format(self.perimetro()))
        return


# 'Main' do programa em si:

# meuretangulo = retangulo(2, 10)
# meuretangulo.saida()
