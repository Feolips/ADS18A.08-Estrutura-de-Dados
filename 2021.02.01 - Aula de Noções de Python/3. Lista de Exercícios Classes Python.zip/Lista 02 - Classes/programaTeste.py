from classeTeste import Teste

for i in range(1, 2):
    novoAluno = Teste()
    novoAluno.setNome(str(input("Nome do {}º Aluno: ".format(i))))

print('Novo aluno: {}'.format(novoAluno.getNome()))
