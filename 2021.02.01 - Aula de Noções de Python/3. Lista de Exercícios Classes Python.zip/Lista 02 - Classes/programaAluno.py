# Programa para executar a classe Aluno 
from classeAluno import Aluno

novoAluno = Aluno()
novoAluno.setNome(str(input("Nome do Aluno: ")))
novoAluno.getNome()
print(novoAluno.getNome())
novoAluno.boletim()

'''
novoAluno.setdataNascimento(str(input("Ano de nascimento: ")))
novoAluno.setcurso(str(input("Curso: ")))
novoAluno.setnota1Bimestre(float(input("Insira a primeira nota: ")))
novoAluno.setnota2Bimestre(float(input("Insira a segunda nota: ")))
print('O aluno {} atingiu a média de {:.2f}, estando portanto {}.'.format
    (nome, getmediaparcial(), textoSituacao))
if situacao = 1:
    novoAluno.setprovaFinal(float(input('Insira a nota da recuperação: ')))
else:
    return

'''
