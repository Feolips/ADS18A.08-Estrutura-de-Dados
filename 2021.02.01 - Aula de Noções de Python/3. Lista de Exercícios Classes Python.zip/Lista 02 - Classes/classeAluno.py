# Declaração da classe Aluno
'''
classe Aluno
Atributos:
- nome: str
- dataNascimento: str
- curso: str
- nota1Bimestre: float
- nota2Bimestre: float
- provaFinal: float
- situacao: str
- mediaFinal: float
Métodos:
+ idade(): integer
+ mediaParcial(): float
+ provaFinal(): void
+ mediaFinal(): float
+ situacao(): str
''' # Enunciado
class Aluno:
    def __init__(self, nome=None):
        self.setNome(nome)
        
        # Métodos para a variável 'nome':
        # Aqui o método 'set' indica a entrada do dado 'nome':
    def setNome(self, nome=None):
        self.nome = nome
        return

        # Aqui o método 'get' indica qual saída de nome deve ser retornada:
    def getNome(self):
        return self.nome
        
    def boletim(self, nome):
        print('   BOLETIM DO ALUNO')
        print('Nome: {}'.format(getNome(nome)))
        print(' Nota 1 | Nota 2 | Prova Final | Média Final | Situação')
        print(' {:.2f} | {:.2f} |   {:.2f}    |    {:.2f}   |   {:.2f}'.format())
        return

'''

-------------------------------RASCUNHO------------------------------------------
class Aluno:
    def __init__(self, nome, dataNascimento, curso, nota1Bimestre = 0.0,
                 nota2Bimestre = 0.0, provaFinal = 0.0, situacao, mediaFinal):
        self.setnome(nome)
        self.setdataNascimento(dataNascimento)
        self.setCurso(curso)
        self.setnota1Bimestre(nota1Bimestre)
        self.setnota2Bimestre(nota2Bimestre)
        self.setprovaFinal(notaProvaFinal)
        self.setsituacao(situacao)
        self.setmediaFinal(mediaFinal)        


        # Métodos para a variável 'dataNascimento':
        # Aqui o método 'set' indica a entrada do dado 'dataNascimento':
        def setDatanascimento(self, dataNascimento):
            self.dataNascimento = dataNascimento
            return

        # Aqui o método 'get' indica qual saída de dataNascimento deve ser retornada:
        def getDatanascimento(self):
            return self.dataNascimento

        # Métodos para a variável 'curso':
        # Aqui o método 'set' indica a entrada do dado 'curso':
        def setCurso(self, curso):
            self.curso = curso
            return

        # Aqui o método 'get' indica qual saída de 'getCurso' deve ser retornada:
        def getCurso(self):
            return self.curso

        # Métodos para a variável 'validaNota':
        # Aqui o método utilizado para validar as notas como float positivo:
        def validaNota(self, nota):
            if isinstance(nota, float) and nota >= 0:
                return nota
            else:
                return 0

        # Aqui o método 'set' indica a entrada validada das notas:
        def setnota1Bimestre(self, nota1):
            self.nota1 = self.validaNota(nota1)
            return
        def setnota2Bimestre(self, nota2):
            self.nota2 = self.validanota(nota2)
            return
        def setprovaFinal(self, notaProvaFinal):
            self.notaProvaFinal = validaNota(notaProvaFinal)

        # Aqui os métodos 'get' indicam quais saídas de notas devem ser retornadas:
        def getnota1Bimestre(self):
            return self.nota1Bimestre
        def getnota2Bimestre(self):
            return self.nota2Bimestre
        def getmediaparcial(self):
            return self.mediaparcial
        def getprovafinal(self):
            return self.notaProvaFinal
        def getsituacao(self):
            return aprovacao(self)

        # Métodos para processamento de dados:
        def mediaparcial(self):
            return (nota1Bimestre+nota2Bimestre)/2
        def mediaFinal(self):
            return (nota1Bimestre + nota2Bimestre)/2 + notaProvaFinal
        def aprovacao(self):
            if mediaparcial() >= 5 or mediaFinal() >= 5:
                textoSituacao = 'aprovado(a)'
                situacao = 0
            elif mediaparcial() >= 4 and mediaparcial() < 5:
                textoSituacao = 'em recuperação'
                situacao = 1
            else:
                textoSituacao = 'reprovado(a)'
                situacao = 2
        def calculaidade(self):
            return (2021 - dataNascimento)
        

notaProvaFinal = input(float('O aluno ficou de Prova Final. Insira a nota da Prova Final para continuar: '))
        # Aqui o método utilizado para validar o Nome como string:
        def validaNome(self, nome):
            if isinstance(nome, str) and nome != 0:
                return nome
            else:
                return inválido

        # Aqui o método utilizado para validar o Nascimento como string:
        def validaNascimento(self, dataNascimento):
            if isinstance((dataNascimento, str)):
                return dataNascimento
            else:
                return Inválido

        def setNota1(self, nota):
            self.nota = nota
    


'''
