from classRetangulodoProfessor import retangulo

meuRetangulo = retangulo()
print('')
meuRetangulo.setlado1(float(input("Informe o Lado 1: ")))
meuRetangulo.setlado2(float(input("Informe o Lado 2: ")))
meuRetangulo.saida()
