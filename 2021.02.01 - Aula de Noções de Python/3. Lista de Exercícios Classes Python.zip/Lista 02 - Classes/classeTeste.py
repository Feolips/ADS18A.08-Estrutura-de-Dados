class Teste:
    def __init__(self, nome=None):
        self.setNome(nome)
        
    def setNome(self, nome):
        self.nome = self.validaNome(nome)
        return
    def getNome(self):
        return self.nome
    def validaNome(self, nome):
        if isinstance(nome, str):
            return nome
        else:
            return 'tipo inválido'