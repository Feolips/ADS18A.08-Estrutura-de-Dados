print('1. Soma de dois números quaisquer:')
V1 = float(input('Insira o primeiro valor: '))
V2 = float(input('Insira o segundo valor: '))
soma = V1+V2
print("Resultado da soma: ", soma)
